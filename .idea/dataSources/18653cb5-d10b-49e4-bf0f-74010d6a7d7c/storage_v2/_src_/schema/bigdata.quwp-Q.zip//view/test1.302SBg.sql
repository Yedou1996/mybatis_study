create definer = root@localhost view test1 as
select `bigdata`.`dept`.`id`     AS `id`,
       `bigdata`.`dept`.`deptno` AS `deptno`,
       `bigdata`.`dept`.`dname`  AS `dname`,
       `bigdata`.`dept`.`loc`    AS `loc`
from `bigdata`.`dept`
where (`bigdata`.`dept`.`deptno` > 105);

