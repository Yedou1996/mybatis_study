create
    definer = root@localhost procedure insert_emp(IN START int(10), IN max_num int(10))
BEGIN
	DECLARE
		i INT DEFAULT 0;
	
	SET autocommit = 0;
	WHILE
			i < max_num DO
			INSERT INTO emp ( empno, ename, job, mgr, hiredate, sal, comm, depno )
		VALUES
			(
				( START + i ),
				rand_string ( 5 ),
				'SALESMAN',
				0001,
				curdate( ),
				2000,
				400,
				rand_num ( ) 
			);
		
		SET i = i + 1;
		
	END WHILE;
	COMMIT;

END;

