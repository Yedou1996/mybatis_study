create
    definer = root@localhost procedure insert_dept(IN START int(10), IN max_num int(10))
BEGIN
	DECLARE
		i INT DEFAULT 0;
	
	SET autocommit = 0;
	WHILE
			i < max_num DO
			INSERT INTO dept ( deptno, dname, loc )
		VALUES
			( ( START + i ), rand_string ( 4 ), rand_string ( 4 ) );
		
		SET i = i + 1;
	END WHILE;
	COMMIT;

END;

