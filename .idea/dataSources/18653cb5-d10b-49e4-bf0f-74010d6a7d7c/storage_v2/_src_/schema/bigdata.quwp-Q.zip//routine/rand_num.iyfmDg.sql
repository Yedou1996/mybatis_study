create
    definer = root@localhost function rand_num() returns int(5)
BEGIN
	DECLARE
		i INT DEFAULT 0;
	
	SET i = floor( 100+rand ( ) * 10 );
	RETURN i;
	
	END;

